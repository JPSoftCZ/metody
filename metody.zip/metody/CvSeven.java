package com.josefpoula.metody;

public class CvSeven {
    public static String cvSeven(String registracka){
        String kraj = "";
        if (registracka.charAt(1) == 'C'){
            kraj = "Jihočeský kraj";
        } return kraj;
    }
}
