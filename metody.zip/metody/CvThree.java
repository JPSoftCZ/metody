package com.josefpoula.metody;

public class CvThree {
    public static void cvThree(String spz){
        if (spz.charAt(1) == 'C'){
            System.out.println("Jihočeský kraj");
        }

    }
}
